import { Header } from "./components/Header/Header.jsx";
import { Login } from "./components/Login/Login.jsx";
import { Footer } from "./components/footer/Footer.jsx";

function App() {
    return (
        <div>
            <Header />
            <Login />
            <Footer />
        </div>
    );
}

export default App;