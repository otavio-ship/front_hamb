export function Header() {
    return (
        <header className="header">
            <img src="/caminho-da-sua-logo.png" alt="Logo Mestre do Hambúrguer" />
        </header>
    );
}