export function Login() {
    return (
        <div className="login">
            <h2>Login</h2>
            <form>
                <div>
                    <label>Email:</label>
                    <input type="email" placeholder="Digite seu email" />
                </div>

                <div>
                    <label>Senha:</label>
                    <input type="password" placeholder="Digite sua senha" />
                </div>

                <button type="submit">Entrar</button>

                <div>
                    <a href="#">Esqueceu sua senha?</a>
                </div>
            </form>
        </div>
    );
}