export function Footer() {
    return (
        <footer className="footer">
            <p>Contato: mestredohamburguer@vendas.com.br</p>
            <p>R: Salvador, nº233</p>
        </footer>
    );
}