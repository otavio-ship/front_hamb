import styles from "./../styles/Footer.module.css";

export function Footer() {

    return (
        <footer className={styles.footer}>
            <p>Contato: mestredohamburguer@vendas.com.br</p>
            <p>R: Salvador, nº233</p>
        </footer>
    );
}
export default Footer
