import styles from "../styles/Header.module.css";
export function Header() {

    return (
        <header className={styles.header}>
            <img src="/logo.png" alt="Logo Mestre do Hambúrguer" />
        </header>
    );
}

export default Header;