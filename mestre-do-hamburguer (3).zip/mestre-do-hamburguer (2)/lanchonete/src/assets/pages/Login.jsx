import styles from "../styles/Login.module.css";
import Header from "./../components/Header.jsx"
import Footer from "../components/Footer.jsx";

function Login() {
    return (
        <div>
            <Header />
            <h2>Login</h2>
            <div className={styles.container}>
                <form>
                    <div>
                        <label>Email:</label>
                        <input
                            type="email"
                            placeholder="Digite seu email"
                        />
                    </div>

                    <div>
                            <label>Senha:</label>

                            <input
                                type="password"
                                placeholder="Digite sua senha"
                            />
                        </div>

                        <button
                            type="submit"
                        >
                            Entrar
                        </button>

                        <div>
                            <a href="#" className={styles.esqueceu}>
                                Esqueceu sua senha?
                            </a>
                        </div>

                    </form>
            <div>
            <Footer />
            </div>

                </div>
        </div>
    );
}

export default Login;