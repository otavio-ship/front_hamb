import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./assets/pages/Login.jsx";
import EsqueciSenha from "./assets/pages/EsqueciSenha.jsx";
import "./App.css";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/EsqueciSenha" element={<EsqueciSenha />} /> </Routes>
        </BrowserRouter>
    );
}

export default App;
