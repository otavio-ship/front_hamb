import styles from "../styles/EsqueciSenha.module.css";
import Header from "../components/Header.jsx";
import Footer from "../components/Footer.jsx";

function EsqueciSenha() {
    return (
        <div className={styles.container}>

            <div className={styles.box}>
                <p>
                    Iremos enviar um código de redefinição de senha,
                    mas primeiro informe seu email.
                </p>

                <label>Email:</label>

                <input type="email" />

                <button>Entrar</button>

            </div>
        </div>
    );
}

export default EsqueciSenha;